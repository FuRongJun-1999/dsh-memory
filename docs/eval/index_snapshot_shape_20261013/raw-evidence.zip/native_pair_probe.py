"""Real temporary-store probes; choose unchanged baseline or fixed checkout."""
import argparse
import json
import os
from pathlib import Path
import sys
import tempfile

p = argparse.ArgumentParser()
p.add_argument('--repo', type=Path, required=True)
p.add_argument('--slug', choices=['jsonl', 'snapshot', 'votes', 'topk'], required=True)
p.add_argument('--output', type=Path)
a = p.parse_args()
sys.path.insert(0, str(a.repo.resolve()))
for key in list(os.environ):
    if key.startswith(('MDCG_', 'DSH_SESSION')):
        os.environ.pop(key)
os.environ.update(MDCG_MASTER_KEY='ab' * 32, MDCG_HOTCACHE='0', MDCG_SUSTAIN='0')
from md_cg.mdcg import MdCG
from md_cg.mdcos import MdCGOS
from md_cg.fsutil import read_jsonl_tail

with tempfile.TemporaryDirectory(prefix='native_pair_') as root:
    cg = MdCGOS(root)
    try:
        if a.slug == 'jsonl':
            row = {'pid': 'committed-later', 'id': 'sample', 'content': '完整中文证据'}
            data = (json.dumps(row, ensure_ascii=False) + '\n').encode()
            cut = data.index('中文'.encode()) + 1
            Path(cg.inbox_log).write_bytes(data[:cut])
            first = list(cg._inbox_records())
            with open(cg.inbox_log, 'ab') as f:
                f.write(data[cut:])
            result = {'first': first, 'after_commit': list(cg._inbox_records()),
                      'fresh_full': read_jsonl_tail(cg.inbox_log, 0)[0]}
        elif a.slug == 'snapshot':
            cg.add('survivor', 'snapshot survivor original content')
            cg.flush()
            cg.rebuild_index()
            original = json.loads(Path(cg.index_path).read_text(encoding='utf-8'))
            result = {}
            for shape in (None, [], 3, {'invalid': None}, {'invalid': []}, {'invalid': {}}):
                doc = dict(original, nodes=shape)
                Path(cg.index_path).write_text(json.dumps(doc), encoding='utf-8')
                try:
                    reopened = MdCG(root)
                    result[repr(shape)] = {'opened': True, 'ids': list(reopened.index['nodes'])}
                    reopened.close()
                except Exception as exc:
                    result[repr(shape)] = {'opened': False, 'error': type(exc).__name__, 'detail': str(exc)}
            cg.rebuild_index()
        elif a.slug == 'votes':
            for i, suffix in enumerate(('', ' alpha', ' beta gamma', ' delta epsilon theta')):
                cg.add(f'seed{i}', 'needle' + suffix,
                       edges=[{'target': 'linked'}, {'target': 'linked'}])
            cg.add('linked', 'separate topic entirely')
            rows, meta = cg.search_rrf('needle', k=20, judge=False, record=False, paths=('bm25', 'graph'))
            result = {'rows': [(r[0]['id'], r[1]) for r in rows],
                      'graph_votes': len(meta['provenance']['linked']), 'meta': meta}
        else:
            text = ('# 功能名：查询助手\n# 生效条件：needle\n# 子功能：检索\n'
                    '# 执行：返回 needle 查询的证据\n# 验证方式：使用测试\n# 不适用条件：{negative}\n')
            for i in range(12):
                cg.add(f'a{i:02}', text.format(negative='forbiddencontext'),
                       verification_basis='test', non_applicable_conditions=['forbiddencontext'])
            cg.add('zsafe', text.format(negative='unrelatedcontext') + ' safe extra text',
                   verification_basis='test', non_applicable_conditions=['unrelatedcontext'])
            rows, meta = cg.search_rrf('needle', k=1, judge=True, judge_ranking=True,
                                      record=False, paths=('lexical',), context={'scene': 'forbiddencontext'})
            result = {'qualified_ids': [r[0]['id'] for r in rows], 'meta': meta}
    finally:
        cg.close()

report = {'slug': a.slug, 'python': sys.version, 'result': result}
if a.output:
    a.output.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps(report, ensure_ascii=False, indent=2))
