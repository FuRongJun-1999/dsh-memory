Synthetic temporary data only. Host paths in logs are normalized; numeric readings and assertion messages are retained.
Original private logs remain local. SHA256SUMS.json covers these public bytes.
Baseline is expected to exit 1 with named assertion failures, zero errors and zero skips.
