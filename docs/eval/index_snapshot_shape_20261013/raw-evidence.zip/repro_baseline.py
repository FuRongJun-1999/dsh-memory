import argparse
from pathlib import Path
import subprocess
import sys
p=argparse.ArgumentParser()
p.add_argument('--baseline',type=Path,required=True)
p.add_argument('--fixed',type=Path,required=True)
p.add_argument('--module',required=True)
a=p.parse_args()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=a.baseline,text=True).strip()
assert head == 'efa2ee2ba4986c02ad204f05a99712c226d0023d', head
assert (a.fixed/'md_cg'/(a.module.rsplit('.',1)[1]+'.py')).is_file()
loader='import sys,runpy,md_cg; md_cg.__path__.append(sys.argv[1]); name=sys.argv[2]; sys.argv=[name]; runpy.run_module(name,run_name="__main__")'
r=subprocess.run([sys.executable,'-X','utf8','-c',loader,str((a.fixed/'md_cg').resolve()),a.module],cwd=a.baseline)
raise SystemExit(r.returncode)
