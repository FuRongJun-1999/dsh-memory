import hashlib
import json
from pathlib import Path
import subprocess
import types
import sys
import argparse
OUT=Path(__file__).resolve().parent
p=argparse.ArgumentParser()
p.add_argument('--repo',type=Path,required=True)
repo=p.parse_args().repo.resolve()
sys.path.insert(0,str(repo))
rows=[]
for commit in ('efa2ee2ba4986c02ad204f05a99712c226d0023d',
               '8b7930db57f13845dca99c41c33ef418ab812aee',
               '84a7ef97d6736f9fe4df9ae69ec4d99f2377619d'):
    source=subprocess.check_output(['git','show',commit+':md_cg/stgidx.py'],cwd=repo)
    module=types.ModuleType('bulk_probe')
    module.__package__='md_cg'
    exec(compile(source,'stgidx.py@'+commit,'exec'),module.__dict__)
    result={'commit':commit,'source_sha256':hashlib.sha256(source).hexdigest(),
            'fixture_python':"{'nodes': {1: {'temporal': 1.0}, 'a': {'temporal': 1.0}}}"}
    try:
        ix=module.build({'nodes':{1:{'temporal':1.0},'a':{'temporal':1.0}}})
        result['broken']=ix.broken
    except Exception as exc:
        result.update(error=type(exc).__name__,detail=str(exc))
    rows.append(result)
assert rows[0].get('broken') is True
assert rows[1].get('error')=='TypeError'
assert rows[2].get('broken') is True
(OUT/'bulk-fallback-review.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8')
print(json.dumps(rows,indent=2))
